import React from 'react'
import Header from '../../components/header/Header'

const Mypost = () => {
  return (
    <>
    <Header />
    {/* <div className="home">
      <Posts data={data}/>
      <Sidebar />
    </div> */}
  </>
  )
}

export default Mypost